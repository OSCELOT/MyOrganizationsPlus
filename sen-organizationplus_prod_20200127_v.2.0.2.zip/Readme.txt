Version: 2.0.0
Date: March 29, 2017
Changes:
- Updated bbversion in manifest